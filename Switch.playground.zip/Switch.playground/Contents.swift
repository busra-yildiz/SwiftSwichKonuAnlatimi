import UIKit

var gun = 9

switch gun {
case 1: print ("pazartesi")
case 2: print ("salı")
case 3: print ("çarşamba")
case 4: print ("perşembe")
case 5: print ("cuma")
case 6: print ("cumartesi")
case 7: print ("pazar")
default: print ("öyle bir gün yok")
}
